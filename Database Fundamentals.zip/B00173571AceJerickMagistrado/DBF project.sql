-- Create the database
DROP DATABASE IF EXISTS hospital_db;
CREATE DATABASE hospital_db;
USE hospital_db;

-- Creating Tables

-- Hospital Info table
CREATE TABLE HOSPITAL_INFO (
    HOSPITAL_ID INT AUTO_INCREMENT PRIMARY KEY,
    HOSPITAL_NAME VARCHAR(200) NOT NULL,
    CEO_NAME VARCHAR(100) NOT NULL,
    ADDRESS VARCHAR(300),
    PHONE VARCHAR(20),
    EMAIL VARCHAR(100),
    ESTABLISHED_DATE DATE
);

-- Department table
CREATE TABLE DEPARTMENT (
    DEPT_ID INT AUTO_INCREMENT PRIMARY KEY,
    DEPT_NAME VARCHAR(100) NOT NULL UNIQUE,
    PHONE VARCHAR(20),
    LOCATION VARCHAR(100),
    HEAD_DOCTOR_ID INT
);

-- Staff table
CREATE TABLE STAFF (
    STAFF_ID INT AUTO_INCREMENT PRIMARY KEY,
    FIRST_NAME VARCHAR(50) NOT NULL,
    LAST_NAME VARCHAR(50) NOT NULL,
    JOB_TITLE VARCHAR(100) NOT NULL,
    DEPT_ID INT NOT NULL,
    HIRE_DATE DATE NOT NULL,
    PHONE VARCHAR(20),
    EMAIL VARCHAR(100),
    SALARY DECIMAL(10,2),
    DAYS_OFF INT DEFAULT 0,
    CONSTRAINT staff_dept_fk FOREIGN KEY (DEPT_ID) 
        REFERENCES DEPARTMENT(DEPT_ID)
);

-- add the head doctor foreign key after staff table exists
ALTER TABLE DEPARTMENT
ADD CONSTRAINT dept_head_fk FOREIGN KEY (HEAD_DOCTOR_ID) 
    REFERENCES STAFF(STAFF_ID);

-- Patient table
CREATE TABLE PATIENT (
    PATIENT_ID INT AUTO_INCREMENT PRIMARY KEY,
    FIRST_NAME VARCHAR(50) NOT NULL,
    LAST_NAME VARCHAR(50) NOT NULL,
    DATE_OF_BIRTH DATE NOT NULL,
    GENDER CHAR(1),
    PHONE VARCHAR(20),
    EMAIL VARCHAR(100),
    ADDRESS VARCHAR(300),
    MEDICAL_HISTORY TEXT,
    BLOOD_TYPE VARCHAR(5),
    EMERGENCY_CONTACT VARCHAR(100),
    EMERGENCY_PHONE VARCHAR(20)
);

-- Treatment table
CREATE TABLE TREATMENT (
    TREATMENT_ID INT AUTO_INCREMENT PRIMARY KEY,
    TREATMENT_NAME VARCHAR(150) NOT NULL,
    DESCRIPTION TEXT,
    COST DECIMAL(10,2) NOT NULL,
    DURATION_DAYS INT,
    DEPT_ID INT NOT NULL,
    CONSTRAINT treatment_dept_fk FOREIGN KEY (DEPT_ID) 
        REFERENCES DEPARTMENT(DEPT_ID)
);

-- Appointment table
CREATE TABLE APPOINTMENT (
    APPT_ID INT AUTO_INCREMENT PRIMARY KEY,
    PATIENT_ID INT NOT NULL,
    STAFF_ID INT NOT NULL,
    TREATMENT_ID INT,
    APPT_DATE DATE NOT NULL,
    APPT_TIME TIME NOT NULL,
    STATUS VARCHAR(20) DEFAULT 'Scheduled',
    NOTES TEXT,
    CONSTRAINT appt_patient_fk FOREIGN KEY (PATIENT_ID) 
        REFERENCES PATIENT(PATIENT_ID),
    CONSTRAINT appt_staff_fk FOREIGN KEY (STAFF_ID) 
        REFERENCES STAFF(STAFF_ID),
    CONSTRAINT appt_treatment_fk FOREIGN KEY (TREATMENT_ID) 
        REFERENCES TREATMENT(TREATMENT_ID)
);


-- ============================================
-- DML STATEMENTS - Inserting Data
-- ============================================

-- Insert hospital information
INSERT INTO HOSPITAL_INFO (HOSPITAL_NAME, CEO_NAME, ADDRESS, PHONE, EMAIL, ESTABLISHED_DATE) 
VALUES ('Mater Private', 'Margarita Magistrado', '123 Healthcare Ave, Dublin', '01-2345678', 'info@stmary.ie', '1985-03-15');

-- Insert departments
INSERT INTO DEPARTMENT (DEPT_ID, DEPT_NAME, PHONE, LOCATION) VALUES
(1, 'Cardiology', '01-2345601', 'Building A, Floor 2'),
(2, 'Orthopedics', '01-2345602', 'Building B, Floor 1'),
(3, 'Pediatrics', '01-2345603', 'Building A, Floor 3'),
(4, 'Neurology', '01-2345604', 'Building C, Floor 2'),
(5, 'Oncology', '01-2345605', 'Building C, Floor 3'),
(6, 'Emergency', '01-2345606', 'Building A, Floor 1'),
(7, 'Radiology', '01-2345607', 'Building B, Floor 2'),
(8, 'Surgery', '01-2345608', 'Building D, Floor 2'),
(9, 'General Medicine', '01-2345609', 'Building A, Floor 4'),
(10, 'Psychiatry', '01-2345610', 'Building E, Floor 1');

-- Insert staff
INSERT INTO STAFF (STAFF_ID, FIRST_NAME, LAST_NAME, JOB_TITLE, DEPT_ID, HIRE_DATE, PHONE, EMAIL, SALARY, DAYS_OFF) VALUES
(1, 'Kavin', 'Smith', 'Cardiologist', 1, '2018-06-15', '087-1234501', 'k.smith@materpriavte.ie', 95000.00, 5),
(2, 'David', 'Krakowiak', 'Orthopedic Surgeon', 2, '2019-03-20', '087-1234502', 'd.krakowiak@materpriavte', 92000.00, 8),
(3, 'Adam', 'Lamont', 'Pediatrician', 3, '2020-01-10', '087-1234503', 'a.lamont@materpriavte', 88000.00, 12),
(4, 'Brandon', 'Finnegan', 'Neurologist', 4, '2017-09-05', '087-1234504', 'b.finnegan@materpriavte', 97000.00, 3),
(5, 'Aravind', 'Binumon', 'Oncologist', 5, '2019-11-12', '087-1234505', 'a.binumon@materpriavte', 98000.00, 7),
(6, 'Aaron', 'Conway', 'Emergency Physician', 6, '2021-02-28', '087-1234506', 'a.conway@materpriavtee', 90000.00, 15),
(7, 'Calum', 'O Connell', 'Radiologist', 7, '2018-07-14', '087-1234507', 'c.oconnell@materpriavte', 89000.00, 10),
(8, 'Denis', 'Bergin', 'Surgeon', 8, '2016-04-22', '087-1234508', 'd.bergin@materpriavte', 105000.00, 4),
(9, 'Ace', 'Magistrado', 'General Practitioner', 9, '2020-08-01', '087-1234509', 'a.magistrado@materpriavte', 75000.00, 20),
(10, 'Amos', 'Farcau', 'Psychiatrist', 10, '2019-05-17', '087-1234510', 'a.farcau@materpriavte', 91000.00, 9),
(11, 'Dmytro', 'Yurchenko', 'Registered Nurse', 1, '2020-09-03', '087-1234511', 'd.yurchenko@materpriavte', 55000.00, 14),
(12, 'Alexandru', 'Belecci', 'Registered Nurse', 3, '2021-06-19', '087-1234512', 'a.belecci@materpriavte', 54000.00, 11),
(13, 'Andrei', 'Scarevnea', 'Office Worker', 9, '2022-01-11', '087-1234513', 'a.scarevnea@materpriavte', 42000.00, 18),
(14, 'Christian', 'O Reilly', 'Office Worker', 6, '2021-11-05', '087-1234514', 'c.oreilly@materpriavte', 41000.00, 16),
(15, 'Liam', 'Gannon', 'Medical Technician', 7, '2020-04-25', '087-1234515', 'l.gannon@materpriavte', 48000.00, 13);

-- update department heads
UPDATE DEPARTMENT SET HEAD_DOCTOR_ID = 1 WHERE DEPT_ID = 1;
UPDATE DEPARTMENT SET HEAD_DOCTOR_ID = 2 WHERE DEPT_ID = 2;
UPDATE DEPARTMENT SET HEAD_DOCTOR_ID = 3 WHERE DEPT_ID = 3;

-- Insert patients - using specific IDs for queries
INSERT INTO PATIENT (PATIENT_ID, FIRST_NAME, LAST_NAME, DATE_OF_BIRTH, GENDER, PHONE, EMAIL, ADDRESS, MEDICAL_HISTORY, BLOOD_TYPE, EMERGENCY_CONTACT, EMERGENCY_PHONE) VALUES
(5612, 'John', 'Bob', '1975-05-12', 'M', '086-1001001', 'john.bob@email.ie', '15 Oak Road, Dublin', 'Hypertension, High cholesterol', 'O+', 'Jane Bob', '086-1001002'),
(3456, 'Alice', 'Murphy', '1988-08-23', 'F', '086-1001003', 'alice.murphy@email.ie', '42 Main Street, Cork', 'Diabetes Type 2, Asthma', 'A+', 'Tom Murphy', '086-1001004'),
(103, 'David', 'OBrien', '1965-11-30', 'M', '086-1001005', 'david.obrien@email.ie', '78 Church Road, Galway', 'Heart Surgery (2020), Diabetes', 'B+', 'Mary OBrien', '086-1001006'),
(104, 'Emma', 'Walsh', '1992-03-17', 'F', '086-1001007', 'emma.walsh@email.ie', '23 Park Avenue, Limerick', 'Allergies (Penicillin)', 'AB+', 'Paul Walsh', '086-1001008'),
(105, 'Michael', 'Kelly', '1980-07-08', 'M', '086-1001009', 'michael.kelly@email.ie', '56 Hill Road, Waterford', 'Broken leg (2019), Healthy', 'O-', 'Sarah Kelly', '086-1001010'),
(106, 'Sophie', 'Ryan', '2010-12-01', 'F', '086-1001011', 'parent.ryan@email.ie', '91 Garden Close, Dublin', 'Childhood asthma', 'A-', 'Catherine Ryan', '086-1001012'),
(107, 'Patrick', 'Connor', '1955-02-14', 'M', '086-1001013', 'patrick.connor@email.ie', '34 Bridge Road, Kilkenny', 'Diabetes, Arthritis', 'B-', 'Anne Connor', '086-1001014'),
(108, 'Olivia', 'Sullivan', '1998-09-25', 'F', '086-1001015', 'olivia.sullivan@email.ie', '67 Sea Road, Wexford', 'Healthy', 'O+', 'James Sullivan', '086-1001016'),
(109, 'William', 'Byrne', '1970-06-18', 'M', '086-1001017', 'william.byrne@email.ie', '12 Lake Drive, Sligo', 'High blood pressure, Diabetes', 'A+', 'Helen Byrne', '086-1001018'),
(110, 'Grace', 'Doyle', '1985-04-22', 'F', '086-1001019', 'grace.doyle@email.ie', '89 Valley Road, Donegal', 'Migraine history', 'AB-', 'Kevin Doyle', '086-1001020');

-- Insert treatments
INSERT INTO TREATMENT (TREATMENT_ID, TREATMENT_NAME, DESCRIPTION, COST, DURATION_DAYS, DEPT_ID) VALUES
(1, 'Heart Surgery', 'Coronary artery bypass surgery', 25000.00, 30, 1),
(2, 'Cardiac Catheterization', 'Diagnostic procedure for heart conditions', 5000.00, 1, 1),
(3, 'Hip Replacement', 'Total hip replacement surgery', 18000.00, 45, 2),
(4, 'Knee Arthroscopy', 'Minimally invasive knee surgery', 7500.00, 14, 2),
(5, 'Pediatric Vaccination', 'Standard childhood immunizations', 150.00, 1, 3),
(6, 'Chemotherapy Session', 'Cancer treatment session', 3500.00, 90, 5),
(7, 'MRI Scan', 'Magnetic resonance imaging', 1200.00, 1, 7),
(8, 'CT Scan', 'Computed tomography scan', 800.00, 1, 7),
(9, 'Appendectomy', 'Surgical removal of appendix', 8500.00, 7, 8),
(10, 'General Consultation', 'Standard doctor consultation', 100.00, 1, 9),
(11, 'Psychiatric Evaluation', 'Mental health assessment', 250.00, 1, 10),
(12, 'Physical Therapy Session', 'Rehabilitation session', 85.00, 30, 2);

-- Insert appointments
INSERT INTO APPOINTMENT (APPT_ID, PATIENT_ID, STAFF_ID, TREATMENT_ID, APPT_DATE, APPT_TIME, STATUS, NOTES) VALUES
(1, 5612, 1, 2, '2024-11-20', '09:00:00', 'Scheduled', 'Follow-up for chest pain'),
(2, 3456, 9, 10, '2024-11-21', '10:30:00', 'Scheduled', 'Routine diabetes check'),
(3, 103, 3, 5, '2024-11-22', '14:00:00', 'Completed', 'Annual vaccination'),
(4, 104, 2, 4, '2024-11-23', '11:00:00', 'Scheduled', 'Post-surgery follow-up'),
(5, 105, 3, 10, '2024-11-24', '15:30:00', 'Scheduled', 'Asthma review'),
(6, 106, 1, 10, '2024-11-25', '09:30:00', 'Scheduled', 'Diabetes management'),
(7, 107, 9, 10, '2024-11-26', '13:00:00', 'Completed', 'General health check'),
(8, 108, 1, 2, '2024-11-27', '10:00:00', 'Scheduled', 'Hypertension monitoring'),
(9, 109, 4, 11, '2024-11-28', '16:00:00', 'Scheduled', 'Migraine consultation'),
(10, 110, 3, 10, '2024-11-29', '11:30:00', 'Scheduled', 'ADHD medication review'),
(11, 5612, 1, 1, '2024-12-05', '08:00:00', 'Scheduled', 'Heart surgery consultation'),
(12, 3456, 9, 10, '2024-12-10', '09:30:00', 'Scheduled', 'Diabetes follow-up'),
(13, 103, 5, 6, '2024-12-12', '13:00:00', 'Scheduled', 'Chemotherapy planning'),
(14, 104, 2, 3, '2024-12-15', '14:00:00', 'Scheduled', 'Hip replacement consultation'),
(15, 105, 10, 11, '2024-12-18', '10:30:00', 'Scheduled', 'Mental health assessment'),
(16, 106, 11, NULL, '2024-12-20', '11:00:00', 'Scheduled', 'Nursing assessment'),
(17, 107, 7, 7, '2024-12-22', '15:00:00', 'Scheduled', 'MRI scan'),
(18, 108, 8, 9, '2024-12-25', '09:00:00', 'Scheduled', 'Appendectomy consultation'),
(19, 109, 15, 8, '2024-12-28', '14:30:00', 'Scheduled', 'CT scan'),
(20, 110, 12, 12, '2024-12-30', '10:00:00', 'Scheduled', 'Physical therapy');


-- ============================================
-- QUERIES - TASK THREE
-- ============================================

-- QUERY 1: Show details of all medical departments
SELECT DEPT_ID, DEPT_NAME, PHONE, LOCATION, HEAD_DOCTOR_ID
FROM DEPARTMENT
ORDER BY DEPT_NAME;


-- 2. Find the contact details of patient "John Bob" whose patient ID is 5612 (2 Marks)
SELECT PATIENT_ID, FIRST_NAME, LAST_NAME,PHONE, EMAIL, ADDRESS,EMERGENCY_CONTACT, EMERGENCY_PHONE
FROM PATIENT 
WHERE PATIENT_ID = 5612;


-- QUERY 3: Update patient 3456 contact details
UPDATE PATIENT
SET PHONE = '086-9999999',
    EMAIL = 'alice.murphy.new@email.ie',
    ADDRESS = '100 New Street, Dublin 8, Ireland'
WHERE PATIENT_ID = 3456;

-- check the update
SELECT PATIENT_ID, FIRST_NAME, LAST_NAME,PHONE, EMAIL, ADDRESS,EMERGENCY_CONTACT, EMERGENCY_PHONE
FROM PATIENT 
WHERE PATIENT_ID = 3456;


-- QUERY 4: Schedule a new medical appointment
INSERT INTO APPOINTMENT (PATIENT_ID, STAFF_ID, TREATMENT_ID, APPT_DATE, APPT_TIME, STATUS, NOTES)
VALUES (5612, 2, 3, '2024-12-15', '10:00:00', 'Scheduled', 'New hip consultation');

SELECT * FROM APPOINTMENT;

-- QUERY 5: Find details of all patients who have Diabetes
SELECT * FROM PATIENT 
WHERE MEDICAL_HISTORY LIKE '%Diabetes%';


-- QUERY 6: Display first and last name of patients under Dr. Kavin Smith
SELECT DISTINCT p.FIRST_NAME, p.LAST_NAME 
FROM PATIENT p
JOIN APPOINTMENT a ON p.PATIENT_ID = a.PATIENT_ID
JOIN STAFF s ON a.STAFF_ID = s.STAFF_ID
WHERE s.FIRST_NAME = 'Kavin' AND s.LAST_NAME = 'Smith';


-- QUERY 7: Change Orthopedics to Orthopedic Surgery Department
UPDATE DEPARTMENT 
SET DEPT_NAME = 'Orthopedic Surgery Department' 
WHERE DEPT_NAME = 'Orthopedics';

SELECT DEPT_ID, DEPT_NAME, PHONE FROM DEPARTMENT WHERE DEPT_ID = 2;

-- 8. Display the first name, surname, and hire date of all doctors sorted in descending order by hire date (2 Marks)
SELECT FIRST_NAME, LAST_NAME, HIRE_DATE 
FROM STAFF 
WHERE JOB_TITLE LIKE '%Doctor%' OR JOB_TITLE LIKE '%Surgeon%' OR JOB_TITLE LIKE '%Physician%' 
   OR JOB_TITLE LIKE '%Cardiologist%' OR JOB_TITLE LIKE '%Neurologist%' 
   OR JOB_TITLE LIKE '%Oncologist%' OR JOB_TITLE LIKE '%Pediatrician%' 
   OR JOB_TITLE LIKE '%Psychiatrist%' OR JOB_TITLE LIKE '%Practitioner%' 
   OR JOB_TITLE LIKE '%Radiologist%'
ORDER BY HIRE_DATE DESC;

-- QUERY 9: Count patients undergoing Heart Surgery
SELECT COUNT(DISTINCT a.PATIENT_ID) AS patient_count
FROM APPOINTMENT a
JOIN TREATMENT t ON a.TREATMENT_ID = t.TREATMENT_ID
WHERE t.TREATMENT_NAME = 'Heart Surgery';


-- QUERY 10: Add one new record to each table
-- hospital info
INSERT INTO HOSPITAL_INFO (HOSPITAL_NAME, CEO_NAME, ADDRESS, PHONE, EMAIL, ESTABLISHED_DATE)
VALUES ('Mater Public', 'Gregorio Magistrado', '456 Medical Park, Dublin 4', '01-8765432', 'contact@materpublic', '2005-09-01');

-- department
INSERT INTO DEPARTMENT (DEPT_NAME, PHONE, LOCATION)
VALUES ('Urology', '01-2345613', 'Building G, Floor 1');

-- staff
INSERT INTO STAFF (FIRST_NAME, LAST_NAME, JOB_TITLE, DEPT_ID, HIRE_DATE, PHONE, EMAIL, SALARY, DAYS_OFF)
VALUES ('Lexie', 'Walsh', 'Urologist', 11, '2024-01-15', '087-1234520', 'c.murphy@materpriavte', 94000.00, 10);

-- patient
INSERT INTO PATIENT (FIRST_NAME, LAST_NAME, DATE_OF_BIRTH, GENDER, PHONE, EMAIL, ADDRESS, MEDICAL_HISTORY, BLOOD_TYPE, EMERGENCY_CONTACT, EMERGENCY_PHONE)
VALUES ('Sean', 'ONeill', '1995-07-20', 'M', '086-2002001', 'sean.oneill@email.ie', '88 Castle Road, Dublin', 'Healthy', 'A+', 'Niamh ONeill', '086-2002002');

-- treatment
INSERT INTO TREATMENT (TREATMENT_NAME, DESCRIPTION, COST, DURATION_DAYS, DEPT_ID)
VALUES ('Kidney Stone Removal', 'Lithotripsy procedure', 4500.00, 3, 11);

-- appointment
INSERT INTO APPOINTMENT (PATIENT_ID, STAFF_ID, TREATMENT_ID, APPT_DATE, APPT_TIME, STATUS, NOTES)
VALUES (111, 16, 13, '2024-12-20', '11:00:00', 'Scheduled', 'First consultation');


-- QUERY 11: Delete one record from all tables
DELETE FROM APPOINTMENT WHERE APPT_ID = 20;
DELETE FROM TREATMENT WHERE TREATMENT_ID = 12;
DELETE FROM PATIENT WHERE PATIENT_ID = 110;
DELETE FROM STAFF WHERE STAFF_ID = 15;
DELETE FROM DEPARTMENT WHERE DEPT_ID = 10;


-- QUERY 12: Total days off for staff ordered by least
SELECT STAFF_ID, FIRST_NAME, LAST_NAME,JOB_TITLE ,DAYS_OFF 
FROM STAFF 
ORDER BY DAYS_OFF ASC;

-- QUERY 13: Change Office Worker to Administrator
UPDATE STAFF
SET JOB_TITLE = 'Administrator'
WHERE JOB_TITLE = 'Office Worker';

SELECT STAFF_ID, FIRST_NAME, LAST_NAME, JOB_TITLE 
FROM STAFF 
WHERE JOB_TITLE = 'Administrator' OR JOB_TITLE = 'Office Worker';


-- QUERY 14: Set Orthopedics department phone to 01-7654321
UPDATE DEPARTMENT
SET PHONE = '01-7654321'
WHERE DEPT_NAME = 'Orthopedics';

SELECT DEPT_ID, DEPT_NAME, PHONE FROM DEPARTMENT WHERE DEPT_NAME LIKE 'Orthopedic%';

-- QUERY 15: Set CEO to Michael Dean
UPDATE HOSPITAL_INFO
SET CEO_NAME = 'Loyd Magistrado'
WHERE HOSPITAL_ID = 1;

SELECT HOSPITAL_ID, HOSPITAL_NAME, CEO_NAME, ADDRESS
FROM HOSPITAL_INFO;


-- QUERY 16: Show staff working longer than 3 years
SELECT * FROM STAFF 
WHERE HIRE_DATE < DATE_SUB(CURDATE(), INTERVAL 3 YEAR);

-- QUERY 17: Show patient names, medical history, appointments (JOIN)
SELECT 
    p.FIRST_NAME, 
    p.LAST_NAME, 
    p.MEDICAL_HISTORY, 
    a.APPT_DATE, 
    a.APPT_TIME, 
    t.TREATMENT_NAME
FROM PATIENT p
JOIN APPOINTMENT a ON p.PATIENT_ID = a.PATIENT_ID
LEFT JOIN TREATMENT t ON a.TREATMENT_ID = t.TREATMENT_ID
ORDER BY a.APPT_DATE, a.APPT_TIME;

-- QUERY 18: Count patients with road in address
SELECT COUNT(*) AS patients_with_road_in_address
FROM PATIENT
WHERE ADDRESS LIKE '%road%' OR ADDRESS LIKE '%Road%';

-- QUERY 19: Create view from three tables
CREATE VIEW patient_appointment_details AS
SELECT 
    p.PATIENT_ID,
    p.FIRST_NAME AS patient_first_name,
    p.LAST_NAME AS patient_last_name,
    a.APPT_DATE,
    a.APPT_TIME,
    a.STATUS,
    s.FIRST_NAME AS doctor_first_name,
    s.LAST_NAME AS doctor_last_name,
    s.JOB_TITLE,
    t.TREATMENT_NAME,
    t.COST
FROM PATIENT p
JOIN APPOINTMENT a ON p.PATIENT_ID = a.PATIENT_ID
JOIN STAFF s ON a.STAFF_ID = s.STAFF_ID
LEFT JOIN TREATMENT t ON a.TREATMENT_ID = t.TREATMENT_ID;

-- To view the created view:
SELECT * FROM patient_appointment_details;

-- QUERY 20: Drop all information in appointments
TRUNCATE TABLE APPOINTMENT;

-- verify its empty
SELECT COUNT(*) AS remaining_appointments FROM APPOINTMENT;
