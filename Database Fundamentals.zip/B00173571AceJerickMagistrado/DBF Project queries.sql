-- ============================================
-- QUERIES - TASK THREE
-- ============================================

-- QUERY 1: Show details of all medical departments
SELECT DEPT_ID, DEPT_NAME, PHONE, LOCATION, HEAD_DOCTOR_ID
FROM DEPARTMENT
ORDER BY DEPT_NAME;


-- 2. Find the contact details of patient "John Bob" whose patient ID is 5612 (2 Marks)
SELECT PATIENT_ID, FIRST_NAME, LAST_NAME,PHONE, EMAIL, ADDRESS,EMERGENCY_CONTACT, EMERGENCY_PHONE
FROM PATIENT 
WHERE PATIENT_ID = 5612;


-- QUERY 3: Update patient 3456 contact details
UPDATE PATIENT
SET PHONE = '086-9999999',
    EMAIL = 'alice.murphy.new@email.ie',
    ADDRESS = '100 New Street, Dublin 8, Ireland'
WHERE PATIENT_ID = 3456;

-- check the update
SELECT PATIENT_ID, FIRST_NAME, LAST_NAME,PHONE, EMAIL, ADDRESS,EMERGENCY_CONTACT, EMERGENCY_PHONE
FROM PATIENT 
WHERE PATIENT_ID = 3456;


-- QUERY 4: Schedule a new medical appointment
INSERT INTO APPOINTMENT (PATIENT_ID, STAFF_ID, TREATMENT_ID, APPT_DATE, APPT_TIME, STATUS, NOTES)
VALUES (5612, 2, 3, '2024-12-15', '10:00:00', 'Scheduled', 'New hip consultation');


-- show the new appointment
SELECT a.APPT_ID, CONCAT(p.FIRST_NAME, ' ', p.LAST_NAME) AS patient_name,
       CONCAT(s.FIRST_NAME, ' ', s.LAST_NAME) AS doctor_name,
       t.TREATMENT_NAME, a.APPT_DATE, a.APPT_TIME, a.STATUS
FROM APPOINTMENT a
INNER JOIN PATIENT p ON a.PATIENT_ID = p.PATIENT_ID
INNER JOIN STAFF s ON a.STAFF_ID = s.STAFF_ID
LEFT JOIN TREATMENT t ON a.TREATMENT_ID = t.TREATMENT_ID
ORDER BY a.APPT_ID DESC 
LIMIT 1;


-- QUERY 5: Find details of all patients who have Diabetes
SELECT * FROM PATIENT 
WHERE MEDICAL_HISTORY LIKE '%Diabetes%';


-- QUERY 6: Display first and last name of patients under Dr. Kavin Smith
SELECT DISTINCT p.FIRST_NAME, p.LAST_NAME 
FROM PATIENT p
JOIN APPOINTMENT a ON p.PATIENT_ID = a.PATIENT_ID
JOIN STAFF s ON a.STAFF_ID = s.STAFF_ID
WHERE s.FIRST_NAME = 'Kavin' AND s.LAST_NAME = 'Smith';


-- QUERY 7: Change Orthopedics to Orthopedic Surgery Department
UPDATE DEPARTMENT 
SET DEPT_NAME = 'Orthopedic Surgery Department' 
WHERE DEPT_NAME = 'Orthopedics';


SELECT DEPT_ID, DEPT_NAME, PHONE FROM DEPARTMENT WHERE DEPT_ID = 2;

-- 8. Display the first name, surname, and hire date of all doctors sorted in descending order by hire date (2 Marks)
SELECT FIRST_NAME, LAST_NAME, HIRE_DATE 
FROM STAFF 
WHERE JOB_TITLE LIKE '%Doctor%' OR JOB_TITLE LIKE '%Surgeon%' OR JOB_TITLE LIKE '%Physician%' 
   OR JOB_TITLE LIKE '%Cardiologist%' OR JOB_TITLE LIKE '%Neurologist%' 
   OR JOB_TITLE LIKE '%Oncologist%' OR JOB_TITLE LIKE '%Pediatrician%' 
   OR JOB_TITLE LIKE '%Psychiatrist%' OR JOB_TITLE LIKE '%Practitioner%' 
   OR JOB_TITLE LIKE '%Radiologist%'
ORDER BY HIRE_DATE DESC;

-- QUERY 9: Count patients undergoing Heart Surgery
SELECT COUNT(DISTINCT a.PATIENT_ID) AS patient_count
FROM APPOINTMENT a
JOIN TREATMENT t ON a.TREATMENT_ID = t.TREATMENT_ID
WHERE t.TREATMENT_NAME = 'Heart Surgery';


-- QUERY 10: Add one new record to each table
-- hospital info
INSERT INTO HOSPITAL_INFO (HOSPITAL_NAME, CEO_NAME, ADDRESS, PHONE, EMAIL, ESTABLISHED_DATE)
VALUES ('Mater Public', 'Gregorio Magistrado', '456 Medical Park, Dublin 4', '01-8765432', 'contact@materpublic', '2005-09-01');

-- department
INSERT INTO DEPARTMENT (DEPT_NAME, PHONE, LOCATION)
VALUES ('Urology', '01-2345613', 'Building G, Floor 1');

-- staff
INSERT INTO STAFF (FIRST_NAME, LAST_NAME, JOB_TITLE, DEPT_ID, HIRE_DATE, PHONE, EMAIL, SALARY, DAYS_OFF)
VALUES ('Lexie', 'Walsh', 'Urologist', 11, '2024-01-15', '087-1234520', 'c.murphy@materpriavte', 94000.00, 10);

-- patient
INSERT INTO PATIENT (FIRST_NAME, LAST_NAME, DATE_OF_BIRTH, GENDER, PHONE, EMAIL, ADDRESS, MEDICAL_HISTORY, BLOOD_TYPE, EMERGENCY_CONTACT, EMERGENCY_PHONE)
VALUES ('Sean', 'ONeill', '1995-07-20', 'M', '086-2002001', 'sean.oneill@email.ie', '88 Castle Road, Dublin', 'Healthy', 'A+', 'Niamh ONeill', '086-2002002');

-- treatment
INSERT INTO TREATMENT (TREATMENT_NAME, DESCRIPTION, COST, DURATION_DAYS, DEPT_ID)
VALUES ('Kidney Stone Removal', 'Lithotripsy procedure', 4500.00, 3, 11);

-- appointment
INSERT INTO APPOINTMENT (PATIENT_ID, STAFF_ID, TREATMENT_ID, APPT_DATE, APPT_TIME, STATUS, NOTES)
VALUES (111, 16, 13, '2024-12-20', '11:00:00', 'Scheduled', 'First consultation');


-- QUERY 11: Delete one record from all tables
DELETE FROM APPOINTMENT WHERE APPT_ID = 20;
DELETE FROM TREATMENT WHERE TREATMENT_ID = 12;
DELETE FROM PATIENT WHERE PATIENT_ID = 110;
DELETE FROM STAFF WHERE STAFF_ID = 15;
DELETE FROM DEPARTMENT WHERE DEPT_ID = 10;


-- QUERY 12: Total days off for staff ordered by least
SELECT STAFF_ID, FIRST_NAME, LAST_NAME,JOB_TITLE ,DAYS_OFF 
FROM STAFF 
ORDER BY DAYS_OFF ASC;

-- QUERY 13: Change Office Worker to Administrator
UPDATE STAFF
SET JOB_TITLE = 'Administrator'
WHERE JOB_TITLE = 'Office Worker';

SELECT STAFF_ID, FIRST_NAME, LAST_NAME, JOB_TITLE FROM STAFF WHERE JOB_TITLE = 'Administrator';

-- QUERY 14: Set Orthopedics department phone to 01-7654321
UPDATE DEPARTMENT
SET PHONE = '01-7654321'
WHERE DEPT_NAME = 'Orthopedics';

SELECT DEPT_ID, DEPT_NAME, PHONE FROM DEPARTMENT WHERE DEPT_NAME LIKE 'Orthopedic%';

-- QUERY 15: Set CEO to Michael Dean
UPDATE HOSPITAL_INFO
SET CEO_NAME = 'Loyd Magistrado'
WHERE HOSPITAL_ID = 1;

SELECT HOSPITAL_ID, HOSPITAL_NAME, CEO_NAME, ADDRESS
FROM HOSPITAL_INFO;


-- QUERY 16: Show staff working longer than 3 years
SELECT * FROM STAFF 
WHERE HIRE_DATE < DATE_SUB(CURDATE(), INTERVAL 3 YEAR);

-- QUERY 17: Show patient names, medical history, appointments (JOIN)
SELECT 
    p.FIRST_NAME, 
    p.LAST_NAME, 
    p.MEDICAL_HISTORY, 
    a.APPT_DATE, 
    a.APPT_TIME, 
    t.TREATMENT_NAME
FROM PATIENT p
JOIN APPOINTMENT a ON p.PATIENT_ID = a.PATIENT_ID
LEFT JOIN TREATMENT t ON a.TREATMENT_ID = t.TREATMENT_ID
ORDER BY a.APPT_DATE, a.APPT_TIME;

-- QUERY 18: Count patients with road in address
SELECT COUNT(*) AS patients_with_road_in_address
FROM PATIENT
WHERE ADDRESS LIKE '%road%' OR ADDRESS LIKE '%Road%';

-- QUERY 19: Create view from three tables
CREATE VIEW patient_appointment_details AS
SELECT 
    p.PATIENT_ID,
    p.FIRST_NAME AS patient_first_name,
    p.LAST_NAME AS patient_last_name,
    a.APPT_DATE,
    a.APPT_TIME,
    a.STATUS,
    s.FIRST_NAME AS doctor_first_name,
    s.LAST_NAME AS doctor_last_name,
    s.JOB_TITLE,
    t.TREATMENT_NAME,
    t.COST
FROM PATIENT p
JOIN APPOINTMENT a ON p.PATIENT_ID = a.PATIENT_ID
JOIN STAFF s ON a.STAFF_ID = s.STAFF_ID
LEFT JOIN TREATMENT t ON a.TREATMENT_ID = t.TREATMENT_ID;

-- To view the created view:
SELECT * FROM patient_appointment_details;

-- QUERY 20: Drop all information in appointments
TRUNCATE TABLE APPOINTMENT;

-- verify its empty
SELECT COUNT(*) AS remaining_appointments FROM APPOINTMENT;